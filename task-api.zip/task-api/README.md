# 📋 Task Manager API

API REST para gerenciamento de tarefas, construída com **Flask** e **SQLite**.

---

## 🗂 Estrutura do Projeto

```
task-api/
├── app.py            # Ponto de entrada — inicializa Flask e banco
├── database.py       # Conexão e criação do banco SQLite
├── models.py         # Funções CRUD (acesso a dados)
├── routes.py         # Rotas REST (Blueprint Flask)
├── requirements.txt  # Dependências
└── README.md
```

---

## 🚀 Como Rodar

```bash
# 1. Instalar dependências
pip install -r requirements.txt

# 2. Subir o servidor
python app.py
# Servidor rodando em http://127.0.0.1:5000
```

> O banco de dados `tarefas.db` é criado automaticamente na primeira execução.

---

## 📡 Rotas da API

### POST `/tarefas` — Criar tarefa
```json
// Body
{ "titulo": "Estudar Flask", "descricao": "Capítulos 1 a 5" }

// Resposta 201
{
  "id": 1,
  "titulo": "Estudar Flask",
  "descricao": "Capítulos 1 a 5",
  "status": "pendente",
  "criado_em": "2025-06-10T14:30:00+00:00"
}
```

---

### GET `/tarefas` — Listar todas as tarefas
```
GET /tarefas
GET /tarefas?status=pendente
GET /tarefas?status=concluido
```
```json
// Resposta 200
{ "total": 2, "tarefas": [ ... ] }
```

---

### GET `/tarefas/{id}` — Buscar por ID
```json
// Resposta 200
{ "id": 1, "titulo": "...", "status": "pendente", ... }

// Resposta 404
{ "erro": "Tarefa 99 não encontrada." }
```

---

### PUT `/tarefas/{id}` — Atualizar tarefa
```json
// Body (todos os campos são opcionais)
{ "titulo": "Novo título", "status": "concluido" }

// Resposta 200
{ "id": 1, "titulo": "Novo título", "status": "concluido", ... }
```

**Valores aceitos para `status`:** `pendente` | `concluido`

---

### DELETE `/tarefas/{id}` — Deletar tarefa
```json
// Resposta 200
{ "mensagem": "Tarefa 1 deletada com sucesso." }

// Resposta 404
{ "erro": "Tarefa 99 não encontrada." }
```

---

## 🧪 Exemplos com cURL

```bash
# Criar
curl -X POST http://localhost:5000/tarefas \
  -H "Content-Type: application/json" \
  -d '{"titulo":"Minha tarefa","descricao":"Descrição aqui"}'

# Listar
curl http://localhost:5000/tarefas

# Buscar por ID
curl http://localhost:5000/tarefas/1

# Atualizar
curl -X PUT http://localhost:5000/tarefas/1 \
  -H "Content-Type: application/json" \
  -d '{"status":"concluido"}'

# Deletar
curl -X DELETE http://localhost:5000/tarefas/1
```
